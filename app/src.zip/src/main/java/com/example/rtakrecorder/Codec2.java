package com.example.rtakrecorder;

import android.media.AudioRecord;
import android.media.AudioTimestamp;

import androidx.annotation.NonNull;

import org.jetbrains.annotations.NotNull;

import java.nio.ByteBuffer;



public class Codec2 implements AutoCloseable {
    static {
        System.loadLibrary("Codec2Binding");
    }

    public static final int REQUIRED_SAMPLE_RATE = 8000;

    public static enum Mode {
        _3200,
        _2400,
        _1600,
        _1400,
        _1300,
        _1200,
        _700C
    }

    public static byte[] makeHeader(int mode, boolean includeFlags) {
        byte[] header = new byte[7];

        header[0] = (byte)0xc0; // Codec2 magic number
        header[1] = (byte)0xde; // Codec2 magic number
        header[2] = (byte)0xc2; // Codec2 identifier
        header[3] = 1; // version_major
        header[4] = 0; // version_minor
        header[5] = (byte)mode; // codec mode
        header[6] = (byte)(includeFlags ? 1 : 0); // flags

        return header;
    }

    public int getEncodedFrameSize() {
        switch (mode) {
            case _3200:// Adjust based on actual frame sizes for each mode
            case _2400:
            case _1600:
                return 8;
            case _1400:
            case _1300:
            case _1200:
            case _700C:
                return 6;
            default:
                throw new IllegalArgumentException("Unsupported mode: " + mode);
        }
    }

    public int getPCMFrameSize() {
        // All modes use 160 PCM samples per frame at 8000 Hz sample rate
        return 160;
    }

    private boolean closed = false;

    private final long codec2StatePtr;
    public final Mode mode;

    private Codec2(long codec2StatePtr, Mode mode) throws RuntimeException {
        this.codec2StatePtr = codec2StatePtr;
        this.mode = mode;
    }

    private static native long nativeCreateCodec2State(int mode, Class<RuntimeException> runtimeExceptionClass) throws RuntimeException;

    @NonNull
    public static Codec2 createInstance(@NotNull Mode mode) throws RuntimeException {
        long codec2StatePtr = nativeCreateCodec2State(mode.ordinal(), RuntimeException.class);
        return new Codec2(codec2StatePtr, mode);
    }

    private static native ByteBuffer nativeEncodeCodec2(long codec2StatePtr, ByteBuffer sampleBuffer, long sampleCount, Class<RuntimeException> runtimeExceptionClass) throws RuntimeException;

    public ByteBuffer encode(@NotNull AudioRecord audioRecord) throws RuntimeException {
        AudioTimestamp audioTimestamp = new AudioTimestamp();
        if (audioRecord.getTimestamp(audioTimestamp, AudioTimestamp.TIMEBASE_MONOTONIC) != AudioRecord.SUCCESS)
            throw new RuntimeException("Error occurred while acquiring AudioTimestamp");

        long bufferSize = audioTimestamp.framePosition * 2;
        if (bufferSize > Integer.MAX_VALUE)
            throw new RuntimeException("Audio buffer size is too large");

        ByteBuffer sampleBuffer = ByteBuffer.allocateDirect((int)bufferSize);
        if (audioRecord.read(sampleBuffer, (int)bufferSize) != bufferSize)
            throw new RuntimeException("Error occurred while reading samples from AudioRecord");

        return nativeEncodeCodec2(codec2StatePtr, sampleBuffer, audioTimestamp.framePosition, RuntimeException.class);
    }

    // Both "directByteBuffer" and "byteArray" cannot be non-null, only one or the other can be passed.
    private static native ByteBuffer nativeDecodeCodec2(long codec2StatePtr, ByteBuffer codec2Buffer, Class<RuntimeException> runtimeExceptionClass) throws  RuntimeException;

    public ByteBuffer decode(@NotNull ByteBuffer codec2Buffer) throws RuntimeException {
        return nativeDecodeCodec2(codec2StatePtr, codec2Buffer, RuntimeException.class);
    }

    private static native void nativeDestroyCodec2State(long codec2StatePtr);

    @Override
    public void close() throws Exception {
        if (!closed) {
            nativeDestroyCodec2State(codec2StatePtr);
            closed = true;
        }
        else
            throw new Exception("Codec2 instance has already been closed");
    }

    @Override
    protected void finalize() {
        if (!closed)
            nativeDestroyCodec2State(codec2StatePtr);
    }
}