#include <jni.h>
#include <codec2.h>
#include <cstdlib>
#include <cstddef>
#include <string>
#include <cmath>

//
// Created by gabeg on 10/29/2024.
//


extern "C"
JNIEXPORT jlong JNICALL
Java_com_example_rtakrecorder_Codec2_nativeCreateCodec2State(JNIEnv *env, jclass clazz, jint mode, jclass runtime_exception_class) {
    int codec2_mode = -1;
    switch (mode) {
        case 0:
            codec2_mode = CODEC2_MODE_3200;
            break;
        case 1:
            codec2_mode = CODEC2_MODE_2400;
            break;
        case 2:
            codec2_mode = CODEC2_MODE_1600;
            break;
        case 3:
            codec2_mode = CODEC2_MODE_1400;
            break;
        case 4:
            codec2_mode = CODEC2_MODE_1300;
            break;
        case 5:
            codec2_mode = CODEC2_MODE_1200;
            break;
        case 6:
            codec2_mode = CODEC2_MODE_700C;
            break;
        default:
            std::string exception_str = "Unknown Codec2 mode ordinal: " + std::to_string(mode);
            env->ThrowNew(runtime_exception_class, exception_str.c_str());
            return 0;
    }

    struct CODEC2* codec2_state = codec2_create(codec2_mode);
    if (codec2_state == nullptr) {
        env->ThrowNew(runtime_exception_class, "Error occurred while creating Codec2 state");
        return 0;
    }

    return reinterpret_cast<jlong>(codec2_state);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_rtakrecorder_Codec2_nativeDestroyCodec2State(JNIEnv *env, jclass clazz, jlong codec2_state_ptr) {
    if (codec2_state_ptr != 0)
        codec2_destroy(reinterpret_cast<CODEC2*>(codec2_state_ptr));
}

extern "C"
JNIEXPORT jobject JNICALL
Java_com_example_rtakrecorder_Codec2_nativeEncodeCodec2(JNIEnv *env, jclass clazz, jlong codec2_state_ptr, jobject direct_byte_buffer, long sample_count, jclass runtime_exception_class) {
    short* pcm_data = reinterpret_cast<short*>(env->GetDirectBufferAddress(direct_byte_buffer));
    if (pcm_data == nullptr) {
        env->ThrowNew(runtime_exception_class,R"(Error occurred while retrieving data pointer from "directByteBuffer")");
        return nullptr;
    }

    CODEC2* codec2_state = reinterpret_cast<CODEC2*>(codec2_state_ptr);
    jint bytes_per_frame = codec2_bytes_per_frame(codec2_state);
    jint samples_per_frame = codec2_samples_per_frame(codec2_state);
    jlong output_buf_size = static_cast<jlong>(ceil(static_cast<double>(sample_count) / samples_per_frame)) * bytes_per_frame;

    unsigned char* output_buffer = reinterpret_cast<unsigned char*>(malloc(output_buf_size));
    if (output_buffer == nullptr) {
        env->ThrowNew(runtime_exception_class, "Error occurred while allocating memory for output buffer");
        return nullptr;
    }

    jlong output_buf_offset = 0;
    for (jlong i = 0; i < sample_count; i += samples_per_frame) {
        if ((sample_count - i) >= samples_per_frame) {
            codec2_encode(codec2_state, &output_buffer[output_buf_offset], &pcm_data[i]);
            output_buf_offset += bytes_per_frame;
        }
        else {
            short padded_input[samples_per_frame];
            memset(padded_input, 0, samples_per_frame * sizeof(short)); // Zero out the padding array.
            memcpy(padded_input, &pcm_data[i], (samples_per_frame - i) * sizeof(short)); // Copy over the remaining PCM data.
            codec2_encode(codec2_state, &output_buffer[output_buf_offset], padded_input);
        }
    }

    return env->NewDirectByteBuffer(output_buffer, output_buf_size);
}

extern "C"
JNIEXPORT jobject JNICALL
Java_com_example_rtakrecorder_Codec2_nativeDecodeCodec2(JNIEnv *env, jclass clazz, jlong codec2_state_ptr, jobject direct_byte_buffer, jclass runtime_exception_class) {
    jlong codec2_data_len = env->GetDirectBufferCapacity(direct_byte_buffer);
    if (codec2_data_len <= -1) {
        env->ThrowNew(runtime_exception_class, R"(Error occurred while retrieving capacity from "directByteBuffer")");
        return nullptr;
    }

    unsigned char* codec2_data = reinterpret_cast<unsigned char*>(env->GetDirectBufferAddress(direct_byte_buffer));
    if (codec2_data == nullptr) {
        env->ThrowNew(runtime_exception_class,R"(Error occurred while retrieving data pointer from "directByteBuffer")");
        return nullptr;
    }

    CODEC2* codec2_state = reinterpret_cast<CODEC2*>(codec2_state_ptr);
    jint bytes_per_frame = codec2_bytes_per_frame(codec2_state);
    jint samples_per_frame = codec2_samples_per_frame(codec2_state);
    jlong output_buf_len = (codec2_data_len / bytes_per_frame) * samples_per_frame;

    jlong output_buffer_size = static_cast<jlong>(output_buf_len * sizeof(short));
    short* output_buffer = reinterpret_cast<short*>(malloc(output_buffer_size));
    if (output_buffer == nullptr) {
        env->ThrowNew(runtime_exception_class, "Error occurred while allocating memory for output buffer");
        return nullptr;
    }

    jint output_buf_offset = 0;
    for (jint i = 0; i < codec2_data_len; i += bytes_per_frame) {
        codec2_decode(codec2_state, &output_buffer[output_buf_offset], &codec2_data[i]);
        output_buf_offset += samples_per_frame;
    }

    return env->NewDirectByteBuffer(output_buffer, output_buffer_size);
}